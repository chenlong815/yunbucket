<?php
namespace Yun_bucket\Controller;
use Think\Controller;

class EmailController extends Controller {
    public function index(){
        $key=I('get.item1');
        $url=GetDownLoadUrl($key,0);
        echo $url;

        $this->display();
//        echo __ROOT__;
    }
}