<?php
namespace Yun_bucket\Controller;
use Think\Controller;

class IndexController extends Controller {
    public function index(){
        $file=getFileList();
//        dump($file);
        $this->assign('files',$file);
////        $this->display('Index/404');
        $this->display();
    }

}