<?php
return array(
	//'配置项'=>'配置值'
    'TMPL_PARSE_STRING'           =>array(
        '__AST__'=>'./Public'
    )
);