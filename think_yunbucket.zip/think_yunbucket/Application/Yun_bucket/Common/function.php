<?php

include 'phpsdk706/autoload.php';

// 引入鉴权类
use Qiniu\Auth;
// 引入上传类
use Qiniu\Storage\UploadManager;
use Qiniu\Storage\BucketManager;

//配置七牛SDK并且获取文件列表
function getFileList(){
    $accessKey = 'IctPS27e8I9j0tg0Drg7WwEsACn-sjwk5NxQQ2HN';
    $secretKey = 'gb-kAwYTalmC0Lrdpj3dHxp1qDbNwrZvAifQUoJf';

//鉴权
    $auth = new Auth($accessKey, $secretKey);

    $bucket = 'testupload';

// 生成上传 Token
    $policy = array(
        'saveKey' => '$(fname)'
    ,"returnUrl"=>'http://123.57.242.185/yunbucket/qiniuyun/Suc_uploadSuccess.html'
    );

    $token = $auth->uploadToken($bucket,null,3600,$policy);

//得到文件列表
    $prefix = '';
    $marker = '';
    $limit = 1000;//限制获取多少条

    $result=ListFile($accessKey,$secretKey,$prefix,$marker,$limit,$bucket);

    return $result;
}

//使用七牛SDK获取指定空间文件列表
function ListFile($accessKey,$secretKey,$prefix,$marker,$limit,$bucket){
    $auth = new Auth($accessKey, $secretKey);
    $bucketMgr = new BucketManager($auth);

    list($iterms,$marker,$err) = $bucketMgr->listFiles($bucket, $prefix, $marker, $limit);

    if ($err !== null) {
        echo "\n====> list file err: \n";
        var_dump($err);
    } else {
        return $iterms;
    }
}

//时间转换函数
function GetTime($tim){
    $da=substr($tim,0,11);
    $ttime=findNum($da);
//    return $ttime;
    return date("Y-m-d H:i:s",$ttime);
}

function findNum($str=''){
    $str=trim($str);
    if(empty($str)){return '';}
    $temp=array('1','2','3','4','5','6','7','8','9','0');
    $result='';
    for($i=0;$i<strlen($str);$i++){
        if(in_array($str[$i],$temp)){
            $result.=$str[$i];
        }
    }
    return $result;
}

//大小转换函数
function GetSize($initsize){
    $changesize='';
    if($initsize<1024){
        $changesize='1 KB';
    }
    if(1024<$initsize&&$initsize<1024000){
        $changesize=(String)round($initsize/1024,0).' KB';

    }elseif(1024000<$initsize&&$initsize<1024000000){
        $changesize=(String)round($initsize/1024000,2).' MB';

    }elseif(1024000000<$initsize){
        $changesize=(String)round($initsize/1024000000,4).' GB';
    }
    return $changesize;
}

//获取下载链接
function GetDownLoadUrl($key,$ifsecret){
    $accessKey = 'IctPS27e8I9j0tg0Drg7WwEsACn-sjwk5NxQQ2HN';
    $secretKey = 'gb-kAwYTalmC0Lrdpj3dHxp1qDbNwrZvAifQUoJf';
    $domain='7xp8g8.com1.z0.glb.clouddn.com';
//初始化Auth状态：
    $auth = new Auth($accessKey, $secretKey);
// 私有空间中的外链 http://<domain>/<file_key>
    $baseUrl = 'http://'.$domain.'/'.$key;

// 对链接进行签名
    $signedUrl = $auth->privateDownloadUrl($baseUrl);
//echo $signedUrl;

    if($ifsecret==0){
        $url=$baseUrl;
    }else{
        $url=$signedUrl;
    }
    return $url;
}