<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <title>邮件发送</title>
    <link rel="stylesheet" type="text/css" href="/think_yunbucket/index.php/Email/Public/Css/style_css.css" />
    <!--<link rel="stylesheet" type="text/css" href="/think_yunbucket/index.php/Email/Public/css/bootstrap.css" />-->
</head>
<body>
2222222
</body>
</html>