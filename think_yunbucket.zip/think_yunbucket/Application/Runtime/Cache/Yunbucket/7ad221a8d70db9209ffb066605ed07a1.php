<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>

</head>
<body>
/think_yunbucket/index.php/Index
</body>
</html>