<?php
namespace YunFile\Controller;
use Think\Controller;
class EmailController extends Controller {
    public function index(){
        $this->display();
    }
}