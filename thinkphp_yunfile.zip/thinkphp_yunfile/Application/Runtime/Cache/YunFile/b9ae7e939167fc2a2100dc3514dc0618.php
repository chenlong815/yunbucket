<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <title>test</title>
    <link rel="stylesheet" type="text/css" href="/thinkphp_yunfile/Public/Css/style2_css.css" />
</head>
<body>
22222222222222
</body>
</html>